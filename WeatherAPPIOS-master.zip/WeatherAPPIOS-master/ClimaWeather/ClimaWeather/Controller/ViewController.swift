//
//  ViewController.swift
//  ClimaWeather
//
//  Created by 00457054 on 21/6/19.
//  Copyright © 2019 00457054. All rights reserved.
//


// Alamofire & SwiftyJSON : https://www.appcoda.com.tw/swift-library-3/
//CoreLocation : 定位 ： http://furnacedigital.blogspot.com/2011/01/corelocation.html

import UIKit
import Alamofire //負責傳輸，取得網路資料
import SwiftyJSON
import CoreLocation //上課沒有交到的
class ViewController: UIViewController,CLLocationManagerDelegate,changeCityDelegate { //changeCityDelegate 定義在 ＣityViewController.swift內
    //conform to the protocol
    func userEnteredANewCityName(city: String) {
        let params: [String : String] = ["q":city, "appid":APP_ID];
        getWeatherData(url: WEATHER_URL, parameters: params);
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "goToSecondPage"
        {
            let destination = segue.destination as! CityViewController;
            destination.formDelegate = self;
            
        }
    }
    
    let locationManager = CLLocationManager();
    
    let WEATHER_URL = "http://api.openweathermap.org/data/2.5/weather" //api網址
    let APP_ID = "e72ca729af228beabd5d20e3b7749713"
    
    let weatherModel = WeatherDataModel();
    
    
    @IBOutlet weak var temperatureLabel: UILabel!
    @IBOutlet weak var weatherIcon: UIImageView!
    @IBOutlet weak var cityLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        locationManager.delegate = self;
        locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters;
        locationManager.requestWhenInUseAuthorization();
        locationManager.startUpdatingLocation();
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    //receive the mesage that the location was updated
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let location = locations[locations.count - 1]
        if location.horizontalAccuracy > 0
        {
            locationManager.stopUpdatingLocation();
            locationManager.delegate = nil;
            let latitude = "\(location.coordinate.latitude)";
            let longtitude = "\(location.coordinate.longitude)";
            let params : [String : String] = ["lat" : latitude ,"lon" : longtitude,"appid":APP_ID];
            getWeatherData(url: WEATHER_URL, parameters:params);
        }
        
    }
    //receive the mesage that the location manager failed to get the location
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        displayError(error: "Location is unavailable!")
    }
    //get weather data function（）
    //補充 ： https://medium.com/allen%E7%9A%84%E6%8A%80%E8%A1%93%E7%AD%86%E8%A8%98/%E5%88%A9%E7%94%A8-alamofire-%E8%99%95%E7%90%86-http-%E8%AB%8B%E6%B1%82-eb62f37118ca
    
    func getWeatherData(url: String, parameters: [String : String])
    {
        Alamofire.request(url, method : .get, parameters: parameters).responseJSON{ //透過url抓（get）跟server要求資料（Alamofire.request）
            response in
            if response.result.isSuccess //response成功
            {
                let weatherJSON : JSON = JSON(response.result.value!); //以確保response 存在
                self.updateWeatherData(json: weatherJSON);
         
            }
            else
            {
                self.displayError(error: "Error finding location! Make sure you are connected to the internet!")
            }
        }
    }
    //display error function Here
    func displayError(error : String)
    {
        // create the alert
        let alert = UIAlertController(title: "Error!", message: error, preferredStyle: UIAlertControllerStyle.alert)
        
        // add an action (button)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
        
        // show the alert
        self.present(alert, animated: true, completion: nil)
    }
    //update weather Data
    func updateWeatherData(json: JSON)
    {
        if let tempResult = json["main"]["temp"].double
        {
            weatherModel.temperature = Int(tempResult - 273.15);
            let city = json["name"];
            weatherModel.city = city.stringValue
            let condition = json["weather"][0]["id"];
            weatherModel.condition = condition.int!;
            weatherModel.weatherIconName = weatherModel.updateWeatherIcon(condition: weatherModel.condition);
            updateUI();
        }
        else
        {
            displayError(error: "Something Went Wrong!");
        }
        
    }
    //update ui with weather data
    func updateUI(){
        cityLabel.text = weatherModel.city;
        temperatureLabel.text = String(weatherModel.temperature);
        weatherIcon.image = UIImage(named: weatherModel.weatherIconName);
        
    }
    
}

