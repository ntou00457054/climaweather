//
//  CityViewController.swift
//  ClimaWeather
//
//  Created by 00457054 on 21/6/19.
//  Copyright © 2019 00457054. All rights reserved.
//

import UIKit
protocol  changeCityDelegate //負責抓取當下的cityName
{
    func userEnteredANewCityName(city: String);
    
}
class CityViewController: UIViewController {
    
    var formDelegate : changeCityDelegate?;
    
    @IBOutlet weak var cityLabel: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    let weatherModel = WeatherDataModel();// 在model下的swift
    
    @IBAction func getWeatherButtonPresssed(_ sender: UIButton) {
        formDelegate?.userEnteredANewCityName(city: cityLabel.text!);
        WeatherDataModel.permanentCityName = cityLabel.text!;
        self.dismiss(animated: true, completion: nil)
    }
    @IBAction func backButtonPress(_ sender: Any) //左上方
    {
        self.dismiss(animated: true, completion: nil) //dismiss用在navigation controller 用於返回上一頁
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
