# WeatherAPPIOS
This app was created using swift for all Apple devices. The application was build using MVC, cocopods like Alamofire for networking, SwiftyJSON in order to parse JSON Data, I also used ProgressHUD 
